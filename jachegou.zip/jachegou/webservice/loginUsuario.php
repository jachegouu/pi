<?php 


	if($_SERVER['REQUEST_METHOD']=='POST'){
		 $username = $_POST["email_field"];
		 $password = $_POST["senha_field"];
		 
		 require '../banco/conexao.php';
		 
		 //$sql = "SELECT * FROM volley WHERE username = '$username' AND password='$password'";
		 
		 $query="SELECT * FROM usuario where email='$username' and senha=md5('$password') ";
		 
		 mysql_query("insert into log (sql_execute) values ('$query')");
		 
		 $result = mysql_query($query);
		 
		 $check = mysql_fetch_array($result);
		 
		 if(isset($check)){
		 	echo 'success';
		 }else{
		 	echo 'failure';
		 	mysql_close($connect);
	 	 }
 }

?>