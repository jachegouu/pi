<?php
session_cache_expire(0);

if($_SERVER["REQUEST_METHOD"]=="POST"){
	require '../banco/conexao.php';
	createUsuario();
}


function createUsuario()
{
	//global $connect;
	
	$nome = $_POST["nome"];	
	$telefone = $_POST["telefone"];
	$rua = $_POST["rua"];
	$bairro = $_POST["bairro"];
	$numero = $_POST["numero"];
	$cep = $_POST["cep"];
	$email = $_POST["email"];
	$senha = $_POST["senha"];
	$imagem = $_POST["imagem"];
	
	$path = "imagem_cliente/".md5(date('l jS \of F Y h:i:s A')).".jpg";
 	file_put_contents($path,base64_decode($imagem));
		
	$query="INSERT INTO usuario	(nome,telefone,bairro,rua,numero,cep,email,senha,path_imagen)
			VALUES 		('$nome','$telefone','$bairro','$rua',$numero,'$cep','$email',md5('$senha'),'$path')";
	
	mysql_query($query) or die (mysql_error($connect));
	mysql_close($connect);
	echo "Inserido com sucesoo !";
	
}








?>