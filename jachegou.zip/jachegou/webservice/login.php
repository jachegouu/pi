<?php

if($_SERVER["REQUEST_METHOD"]=="GET"){
	require '../banco/conexao.php';
	loginUsuario();
}


function loginUsuario()
{
	
	$email = $_GET['email_usuario'];
	$senha = $_GET['senha_usuario'];
		
	$query="SELECT * FROM usuario ";
	
	$result  = mysql_query($query) or die (mysql_error($connect)); 	
	
		 
	if(mysql_num_rows($result)>0){	    
			$row = mysql_fetch_assoc($result);
			
			
			$json=array(
				'usuario'=>$row
			);
			
			//$temp_array[] = $row;	
			//header('Content-Type: application/json');
			echo json_encode($json);					
	}else{
		
	}
	mysql_close($connect);		
	
}
?>