<?php header("Content-type: text/html; charset=iso8859-1"); ?>
<html lang="pt-br">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Cadastrar Estabelecimento</title>
<link href="./bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="./bootstrap/starter-template.css" rel="stylesheet">
<link href="./css/css_personalizado.css" rel="stylesheet">
<script src="./js/Funcao.js"></script>
</head>
<body>
<?php include 'menu.php';?>
<div class="col-md-12" style="background-color: #0174DF;display: block;">
</div>
<div class="navbar navbar-default navbar-fixed-bottom footer">
		<h1 style="text-align: center;color: white;" >Sistema de Gerencimento Já Chegou</h1>
</div>

</body>		
</html>