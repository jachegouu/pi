<?php header("Content-type: text/html; charset=iso8859-1"); ?>
<?php $arrayList=null;?>
<html lang="pt-br">
<head>
<title>Cadastrar Estabelecimento</title>
<link href="./bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="./bootstrap/starter-template.css" rel="stylesheet">
<link href="./css/css_personalizado.css" rel="stylesheet">
<script src="./js/Funcao.js"></script>
</head>
<body>
<?php include 'menu.php';?>
<div class="col-md-12" style="background-color: #0174DF;display: block;">
 			<h1 style="text-align: center;color: white;">Cadastro de Estabelecimentos</h1>
</div>
 <div class="container-fluid">    	
    	<form action="./controller/cliente/salvar.php" method="post" id="form">
			<div class="col-md-12">
				<input type="hidden" class="form-control" name="id" id="id" value="<?php echo  ($arrayList[0]!=null)? $arrayList[0]:"null"?>">
			</div>
			<div class="col-md-12">
				<div class="col-md-3">				
					<img alt="imagem-foto-estabeliciemto-padrao" src="./img/imagem-loja-padrao.png">					
				</div>
			</div>
			<div class="col-md-12">
				<div class="col-md-3">
					<input type="file" class="form-control" name="arquivo" id="arquivo" value="<?php echo  ($arrayList[0]!=null)? $arrayList[0]:"null"?>">
				</div>
			</div>
			<div class="col-md-12">
				<div class="col-md-3">				
				<select class="form-control" id="situacao" name="situacao">
					<option value="1">Ativo</option>
					<option value="0">Exclu�do</option>
				</select>
				</div>
			</div>
			<div class="col-md-12" style="margin-top: 5px;">			
				<div class="col-md-8">						
						<input type="text" class="form-control" name="descricao" id="descricao" placeholder="Nome do Estabelicimento..." value="<?php echo  ($arrayList[0]!=null)?$arrayList[1]:""?>">
				</div>				
			</div>	
			
			
			<div class="col-md-12" style="margin-top: 5px;">			
				<div class="col-md-4">						
						<input type="text" class="form-control" name="cpf" id="cpf" placeholder="Insira o CNPJ..." value="<?php echo  ($arrayList[0]!=null)?$arrayList[4]:""?>" 
						onkeypress="mascara(this, '###.###.###/####-##')" maxlength="14">
				</div>
				<div class="col-md-2">					
						<input type="text" class="form-control" name="celular" id="celular" placeholder="Insira o celular de contato..."  value="<?php echo  ($arrayList[0]!=null)?$arrayList[6]:""?>"
						onkeypress="mascara(this, '## #####-####')" maxlength="13">
				</div>
				<div class="col-md-2">					
						<input type="text" class="form-control" name="telefone" id="telefone" placeholder="Insira o telefone do contato..."  value="<?php echo  ($arrayList[0]!=null)?$arrayList[5]:""?>"
						onkeypress="mascara(this, '## ####-####')" maxlength="13">
				</div>
			</div>
			<div class="col-md-12" style="margin-top: 5px;">			
				<div class="col-md-8">						
						<input type="text" class="form-control" name="endereco" id="endereco" placeholder="Endere�o do estabelicimento..." value="<?php echo  ($arrayList[0]!=null)?$arrayList[1]:""?>">
				</div>				
			</div>
			
			<div class="col-md-12" style="margin-top: 5px;">						
					<div class="col-md-4">						
							<input type="text" class="form-control" name="bairro" id="bairro" placeholder="Bairro residencia..." value="<?php echo  ($arrayList[0]!=null)?$arrayList[1]:""?>">
					</div>		
					
					<div class="col-md-2">						
							<input type="text" class="form-control" name="numero" id="numero" placeholder="numero da casa..." value="<?php echo  ($arrayList[0]!=null)?$arrayList[1]:""?>">
					</div>				
							
					<div class="col-md-2">						
							<input type="text" class="form-control" name="complemento" id="complemento" placeholder="Complementos..." value="<?php echo  ($arrayList[0]!=null)?$arrayList[1]:""?>">
					</div>				
				
			</div>
			<div class="col-md-12" style="margin-top: 5px;">
				<div class="col-md-6">					
						<input type="text" class="form-control" name="email" id="email" placeholder="E-mail do Cliente..." value="<?php echo  ($arrayList[0]!=null)?$arrayList[2]:""?>">
				</div>
				<div class="col-md-2">					
						<input type="password" class="form-control" name="senha" id="senha" placeholder="Senha do Cliente..."  value="<?php echo  ($arrayList[0]!=null)?"123456":""?>">
				</div>
			</div>			
							
			<div class="col-md-12" style="margin-top: 5px;">
				    <div class="col-md-12" style="margin-top: 5px;margin-bottom: 5px;">
				     <a href="./listaCliente.php">
						<button type="submit" class="btn btn-primary btn-lg active">
							<span>Voltar</span>
						</button>
					</a>
					<button type="submit" class="btn btn-primary btn-lg active" id="saveButton">Salvar</button>
				</div>	
			</div>
		</form>	
</div>
<br>
<br>
<br>
<br>    
<div class="navbar navbar-default navbar-fixed-bottom footer">
		<h1 style="text-align: center;color: white;" >Sistema de Gerencimento J� Chegou</h1>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="./bootstrap/dist/js/bootstrap.min.js"></script>
<script src="./js/jquery.js"></script>
</body>		
</html>