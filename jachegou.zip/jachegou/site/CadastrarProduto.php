<?php header("Content-type: text/html; charset=iso8859-1"); ?>
<?php 
	include_once 'banco/conexao.php';
	require_once './controller/ListaCategoria.php';
	$categoria=new ListaCategoria();
	$listaCategoria=$categoria->lista();
	$bean=mysql_fetch_array(mysql_query("select * from produto_estabelecimento where id=".$_GET['id']));
?>
<html lang="pt-br">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Cadastrar Estabelecimento</title>
<link href="./bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="./bootstrap/starter-template.css" rel="stylesheet">
<link href="./css/css_personalizado.css" rel="stylesheet">
<script src="./js/Funcao.js"></script>
</head>
<body>
<?php include 'menu.php';?>
<div class="col-md-12" style="background-color: #0174DF;display: block;">
 			<h1 style="text-align: center;color: white;">Cadastro de Produtos</h1>
</div>
<form action="./controller/salvarProduto.php" method="post" enctype="multipart/form-data">
 <div class="container-fluid" > 
    		<div class="col-md-6">
			<div class="form-group">
				<input type="hidden" class="form-control" name="id" id="id" value="<?php echo  ($bean[0]!=null)?$bean[0]:"0"?>">
			</div>
			<div class="form-group">
				<label class="font3">Descri��o Produto: </label>
				<input type="text" class="form-control" name="descricao" id="descricao" value="<?php echo  ($bean[0]!=null)?$bean[3]:""?>">
			</div>
			<div class="form-group">
			<label class="font3">Categoria Produto:</label>
				<select class="form-control" id="tipo" name="tipo">
					<?php while ($categoriaBean=mysql_fetch_array($listaCategoria)){?>
					<option value="<?php echo $categoriaBean[0] ?>"><?php echo $categoriaBean[1] ?></option>
					<?php }?>					
				</select>
			</div>
			<div class="form-group">
				<label class="font3">Imagem Produto:</label>				
				<input type="file" class="form-control" id="arquivo" name="arquivo" onchange="exibirImagem(this,'mini_foto_new');" value="<?php echo  ($bean[0]!=null)?$bean[5]:""?>" >
			</div>
			
			<img id="mini_foto_new" class="mini_foto"  width="50%" height="300px" src="<?php echo  ($bean[0]!=null)?$bean[5]:"img/img.png"?>"/>
			
			<div class="form-group">
				<label class="font3">Ingredientes: </label>
				<textarea rows="10" cols="20" class="form-control" id="ingredientesProdutos" name="ingredientesProdutos"><?php echo  ($bean[0]!=null)?$bean[4]:""?></textarea>
			</div>			
			<div class="form-group">
				<label class="font3">Valor Venda:</label>
				<input type="text" class="form-control" name="valor" id="valor" value="<?php echo  ($bean[0]!=null)?$bean[6]:""?>">
			</div>
			
			<label class="font3">Situa��o:</label>
				<select class="form-control" id="situacao" name="situacao">
					<option value="1" <?php echo  ($bean[7]=="1")?'selected':""?>>ATIVO</option>
					<option value="0" <?php echo  ($bean[7]=="0")?'selected':""?>>EXCLU�DO</option>					
				</select>
			</div>
	
			<div class="col-md-12">
				<button type="submit" class="btn btn-primary btn-lg active" id="saveButton">Salvar</button>				
			</div>
</div>
</form>
<br>
<br>
<br>
<br>    
<div class="navbar navbar-default navbar-fixed-bottom footer">
		<h1 style="text-align: center;color: white;" >Sistema de Gerencimento J� Chegou</h1>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="./bootstrap/dist/js/bootstrap.min.js"></script>
<script src="./js/jquery.js"></script>
</body>		
</html>