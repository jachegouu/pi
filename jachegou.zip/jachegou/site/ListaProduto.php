<?php header("Content-type: text/html; charset=iso8859-1"); ?>
<?php include 'banco/conexao.php';?>
<html lang="pt-br">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Cadastrar Estabelecimento</title>
<link href="./bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="./bootstrap/starter-template.css" rel="stylesheet">
<link href="./css/css_personalizado.css" rel="stylesheet">
<script src="./js/Funcao.js"></script>
</head>
<body>
<?php include 'menu.php';?>
<div class="col-md-12" style="background-color: #0174DF;display: block;">
 			<h1 style="text-align: center;color: white;">Cadastro de Produtos</h1>
</div>
 <?php
	$arrayResult = mysql_query("select * from produto_estabelecimento");
 ?>


		
		<table class="table">
						<tr>
							<th class="font4" style="width: 10%">C�digo : </th>				
							<th class="font4"  style="width: 30%">Descri��o :</th>											
							<th class="font4"  style="width: 15%">valor :</th>					
							<th class="font4"  style="width: 15%">Situa��o :</th>
							<th class="font4"  style="width: 15%">Imagem :</th>	
							<th class="font4"  style="width: 15%;text-align: center;">Editar :</th>							
						</tr>
		
						<?php while ($array = mysql_fetch_array($arrayResult)){?>
								<tr class="font3">						
									<td class="font3"><?php echo $array[0]?></td>				
									<td class="font3"><?php echo $array[3]?></td>				
									<td class="font3"><?php echo "R$ ".number_format($array[6], 2, ',', '.')?></td>
									<td class="font3"><?php echo ($array[7]==1)?'ATIVO':'EXCLU�DO'?></td>
						<td class="font3"><img class="imagem col-md-6" src="./<?php echo $array[5]?>" alt="imagenProduto"></td>
									<td class="button-column" style="text-align: center;">						
										<a href="./CadastrarProduto.php?id=<?php echo $array[0]?>">
										<button type="submit" class="btn btn-default btn-lg">
											<span class="glyphicon glyphicon-edit"></span>
										</button>
										</a>
									</td>									
						       </tr>

		<?php }?>
		</table>		

 </div>
<br>
<br>
<br>
<br>    
<div class="navbar navbar-default navbar-fixed-bottom footer">
		<h1 style="text-align: center;color: white;" >Sistema de Gerencimento J� Chegou</h1>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="./bootstrap/dist/js/bootstrap.min.js"></script>
<script src="./js/jquery.js"></script>
</body>		
</html>