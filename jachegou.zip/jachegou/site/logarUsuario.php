<?php

/*require_once("conexao.php");*/
include("/Banco/conexao.php");
session_start();

  if ($_SERVER['REQUEST_METHOD'] == 'POST') {

  $usuario = ($_POST['login']);
  $senha = ($_POST['senha']);
  $tipoacesso = ($_POST['tipoacesso']);

  
  if ($tipoacesso == 0){
  	$sql = "SELECT id, usuario, senha FROM jachegou.usuarios WHERE usuario = '$usuario' and senha = '$senha'";  
  }else {
  	$sql = "SELECT id, nome_estabelecimento, usuario, senha FROM jachegou.usuarios_estabelecimentos WHERE usuario = '$usuario' and senha = '$senha'";
  }
  $result = mysql_query($sql);
  $row = mysql_num_rows($result);
  
  if($row >= 1 && $tipoacesso==0) {
  	
    header("Location: CadastrarCliente.php");
  } elseif ( $row>=1 && $tipoacesso >= 1) {
  		header("Location: welcome.php");  			
  	} else{
  		header("Location: login.php?erro=1");
  	}	

  	session_register("login");
  	$_SESSION['login'] = $usuario;
    //echo "usuario:".$usuario." Senha".$senha." count:".$count;
    
    //header("Location: login.php?erro=1");
    //echo $sql;
    //print mysql_fetch_array($result);

}


?>