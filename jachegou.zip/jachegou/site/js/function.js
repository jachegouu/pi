/**
 * 
 */
function buscarFiliais(){
	var loja = $('#loja').val();
		if(loja){
			var url = 'filiais.php?id='+loja;
			$.get(url, function(dataReturn) {
              $('#load_filiais').html(dataReturn);
			});
		}
}
