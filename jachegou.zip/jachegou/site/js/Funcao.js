/**
 * 
 */
function SomenteNumero(e){
    var tecla=(window.event)?event.keyCode:e.which;   
    if((tecla>47 && tecla<58)) return true;
    else{
    	if (tecla==8 || tecla==0) return true;
	else  return false;
    }
}
//onkeypress='return SomenteNumero(event)'
function mascara(t, mask){
	 var i = t.value.length;
	 var saida = mask.substring(1,0);
	 var texto = mask.substring(i)
	 if (texto.substring(0,1) != saida){
	 t.value += texto.substring(0,1);
	 }
}
//onkeypress="mascara(this, '#####-###')" maxlength="9"

function mostrarImagenProduto(){
	//var id = $('#srcimagen').val();
	alert(document.getElementById('srcimagen').html);
		if(id){
			var url = 'montarImagen.php?src='+document.getElementById('srcimagen').value;
			$.get(url, function(dataReturn) {
              $('#imagem').html(dataReturn);
			});			
		}
}
function exibirImagem(input, id) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('#'+id)
	.attr('src', e.target.result)
	;
        }

        reader.readAsDataURL(input.files[0]);
    }
}


function buscarSetores(){	
	var codigo = $('#codigo').val();
	var descricao = $('#descricao').val();
	var situacao = $('#situacao').val();
		
			var url = 'lista.php?codigo='+codigo +'&descricao='+descricao+'&situacao='+situacao;
			
			$.get(url, function(dataReturn) {
              $('#lista').html(dataReturn);
			});
		
}	
function excluirSetor(codigo){
	var url = '../../controller/setor/excluir.php?codigo='+codigo;
			
		$.get(url, function(dataReturn) {
			buscarSetores();			
		});
		
}

function listarImpressora(){	
	var loja = $('#setor').val();
		if(loja){
			var url = '../functions/listarImpressoras.php?id='+loja;
			$.get(url, function(dataReturn) {
              $('#impressora').html(dataReturn);
			});
			
		}
}
function mensagemSolicitacao(t){
	var t= $('#tipo').val();
	if (t==1){
		$('#mensagem').html('<label for="NToners">Mensagem :</label><br><textarea rows="5" class="form-control" id="mensagem" name="mensagem"></textarea>');
	}else {
		$('#mensagem').html('');	
	}
		
}
function tipoImpressora(){
	var e = document.getElementById("impressoraId");
	var t= e.options[e.selectedIndex].text;
	alert(t);
	var res = t.replace("COLORIDA", "");
	alert(res);
	if (t!=res){
		$('#cores').html('<div class="form-group col-md-3">' +
					'<label for="descricao">Qts. Tonner Preto :</label> <input  type="text" class="form-control" name="preto" id="preto">' +
				'</div>' +
				'<div class="form-group col-md-3">' +
					'<label for="descricao">Qts. Tonner Azul :</label> <input  type="text" class="form-control" name="azul" id="azul">' +
				'</div>' +				
				'<div class="form-group col-md-3">' +
				'	<label for="descricao">Qts. Tonner Vermelho :</label> <input  type="text" class="form-control" name="vermelho" id="vermelho">'+
				'</div>'+
				
				'<div class="form-group col-md-3">'+
				'	<label for="descricao">Qts. Tonner Amarelo :</label> <input  type="text" class="form-control" name="amarelo" id="amarelo">'+
				'</div>');
	}else {
		$('#cores').html('<div class="form-group col-md-3">' +
					'<label for="descricao">Qts. Tonner Preto :</label> <input  type="text" class="form-control" name="preto" id="preto">' +
				'</div>');		
	}
}
