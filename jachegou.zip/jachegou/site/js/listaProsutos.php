<?php header("Content-type: text/html; charset=iso8859-1"); ?>
<?php include '/banco/conexao.php';?>
<html>
<head>
<title>J� Chegou</title>
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="bootstrap/starter-template.css" rel="stylesheet">
<link href="css/css_personalizado.css" rel="stylesheet">
<script src="js/Funcao.js"></script>
</head>
<body style="background-color: black;color: white;">
 <div class="container-fluid" >
 <?php
	$array = mysql_query("select * from produto_estabelecimento");
 ?>


<?php while ($array = mysql_fetch_array($result1)){?>
		
		<table class="table">
						<tr>
							<th class="font4" style="width: 10%">C�digo : </th>				
							<th class="font4"  style="width: 15%">Descri��o :</th>
							<th class="font4"  style="width: 10%">Imagem Produto :</th>							
							<th class="font4"  style="width: 10%">valor :</th>					
							<th class="font4"  style="width: 10%">Situa��o :</th>
						</tr>
		
						
								<tr class="font3">						
									<td class="font3"><?php echo $array[0]?></td>				
									<td class="font3"><?php echo $array[3]?></td>									
									<td class="font3"><img src="./<?php echo $array[5]?>" alt="imagenProduto"></td>		
									<td class="font3"><?php echo "R$ ".number_format($array[6], 2, ',', '.')?></td>
									<td class="font3"><?php echo ($array[6]==1)?'ATIVO':'EXCLU�DO'?></td>
						       </tr>
		
		</table>		
<?php }?>
 </div> 
<script src="js/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<script src="js/jquery.js"></script>
</body>
</html>