<?php
	include '../functions/conexao.php';
	
	class banco{
		function listaValores() {
			session_start();
			$codigo=$_SESSION['codigo'];
						
			$arrayList = mysql_query("SELECT 
											v.id,
										    v.descricao,
										    m.mes,
										    m.ano,
										    sum(m.quantidade) as quantidade,										    
										    sum((m.quantidade*m.valor_pagina)) as valor_total
										from  
											loja l    
										    inner join impressora i on i.id_loja=l.id
										    inner join medidores m on m.id_impressora=i.id
										    inner join cliente v on v.id=l.id_cliente
										where v.id=$codigo
										group by v.id,m.mes,m.ano");
			return $arrayList;
		}
		///tem que olha a questao de pegar os medidores do m�s passado
		function listaMedidores($idLoja){
			session_start();
			$codigo=$_SESSION['codigo'];
			
			$arrayList = mysql_query("select i.id,
											   i.descricao,
											   i.patrimonio,
											   s.descricao as setor,
											   date_format(now(),'%d/%m/%Y') as data ,
											   (select m.quantidade from medidores m where m.mes=(date_format(now(),'%m')-1) and m.ano=date_format(now(),'%Y') and m.id_impressora=i.id) as quantidade,
                                               (select m.quantidade from medidores m where m.mes=(date_format(now(),'%m')) and m.ano=date_format(now(),'%Y') and m.id_impressora=i.id) as quantidade2,
                                               l.descricao
										from 	
											impressora i
                                            inner join loja l on l.id=i.id_loja
											inner join setor s on s.id=i.id_setor
			where l.id_cliente=$codigo and l.id=$idLoja ORDER BY l.descricao");
			return $arrayList;
		}
		function listaLojaMedidores(){
			session_start();
			$codigo=$_SESSION['codigo'];
			
			$arrayList = mysql_query("select distinct
											l.id,
											l.descricao
										from
											impressora i
										    inner join loja l on l.id=i.id_loja										
										where 
											l.id_cliente=$codigo ORDER BY l.descricao");
			return $arrayList;			
		}
		
		
		function quantidadePaginaMesPassado($idImpressora){
			
			$mes=date('m');
			if (($mes-1)==0){
				$array=mysql_fetch_array(mysql_query("select quantidade from medidores 
				where mes=12 and ano=(date_format(now(),'%Y')-1) and id_impressora=$idImpressora"));
			}else {
				$array=mysql_fetch_array(mysql_query("select quantidade from medidores 
				where mes=(date_format(now(),'%m')-1) and ano=date_format(now(),'%Y') and id_impressora=$idImpressora"));	
			}
			return $array[0];
		}
		function saveMedidor($idImpressora,$quantidade){
			
			//verificar se j� foi inserido algum valor no banco neste mes
			$result=mysql_num_rows(mysql_query("select m.quantidade from medidores m 
										where m.mes=(date_format(now(),'%m')) 
										and m.ano=date_format(now(),'%Y') and m.id_impressora=".$idImpressora));
			
			//aki vai pegar o valor por pagina impressa por cliente
			$array_valores=mysql_fetch_array(mysql_query("select c.valor_pagina,c.valor_pagina_colorida from cliente c, impressora i, 
														loja l where i.id_loja=l.id and c.id=l.id_cliente and i.id=$idImpressora"));
			$valor_preto=$array_valores[0];
			$valor_colorido=$array_valores[1];		
			
			//akie temos que verificar se a impressora e colorida ou n�o
			$colorida=mysql_fetch_array(mysql_query("select colorida from impressora where id=$idImpressora"));
			
			if ($colorida[0]==1){
				$valor_inserir=$valor_colorido;					
			}else{
				$valor_inserir=$valor_preto;
			}
			
			
			if ($result!=1){
				$sql="INSERT INTO `acopiadora`.`medidores`
				(id_impressora,quantidade,mes,ano,valor_pagina)
				VALUES (".$idImpressora.",".$quantidade.",date_format(now(),'%m'),date_format(now(),'%Y'),$valor_inserir)";				
			}else {
				$sql="UPDATE `acopiadora`.`medidores`
				SET quantidade=".$quantidade."
				 WHERE id_impressora=".$idImpressora." and  mes=(date_format(now(),'%m')) 
											and ano=date_format(now(),'%Y')";
			}
			mysql_query($sql);
		}
		
		function listarLojaMedidoreValor($mes,$ano){
			session_start();
			$codigo=$_SESSION['codigo'];
			
			return mysql_query("select distinct l.id,l.descricao from medidores m,impressora i, loja l
 											where m.id_impressora=i.id and l.id=i.id_loja and m.mes=$mes and m.ano=$ano and l.id_cliente=$codigo");
		}
		
		function listarImpressoraMedidorLoja($mes,$ano,$loja){
			
			return mysql_query("select i.descricao,i.patrimonio,s.descricao,m.quantidade,m.valor_pagina,(m.quantidade*m.valor_pagina) as valor_pagina
								from medidores m, impressora i, loja l, setor s where m.id_impressora=i.id and i.id_loja=l.id and s.id=i.id_setor 
								and l.id=$loja and m.mes=$mes and m.ano=$ano");
		}
		
	}

?>
