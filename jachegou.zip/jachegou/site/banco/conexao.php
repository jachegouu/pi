<?php

/*error_reporting(0);
ini_set('display_errors', 0);

// fechar uma conexão com mysql
$conexao = mysql_connect("localhost", "root", "root");
mysql_set_charset('UTF8');

if (isset($conexao)) {
	// selecionar o bd
	if (!mysql_select_db("jachegou")) {
		die("Erro ao selecionar BD: " . mysql_error());
	}
} else {
	die("Erro ao conectar BD: " . mysql_error());
}*/


error_reporting(0);
ini_set('display_errors', 0);

// fechar uma conexão com mysql
$conexao = mysql_connect("localhost", "ceramisc_consult", "67673030");
mysql_set_charset('UTF8');

if (isset($conexao)) {
	// selecionar o bd
	if (!mysql_select_db("ceramisc_jachegou")) {
		die("Erro ao selecionar BD: " . mysql_error());
	}
} else {
	die("Erro ao conectar BD: " . mysql_error());
}



?>