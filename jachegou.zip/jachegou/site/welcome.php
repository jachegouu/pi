<?php

   echo "<h1><b> Bem vindo Estabelecimento!!!!</b></h1>"

?>