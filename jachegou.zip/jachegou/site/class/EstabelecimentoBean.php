<?php
	class EstabelecimentoBean{
		private $id;
		private $nome;
		private $cnpj;
		private $email;
		private $senha;		
		private $telefone;
		private $celular;
		private $endereco;
		private $bairro;
		private $numero_casa;
		private $complemento;
		private $pathImagem;
		
		function setEstabelicimento($id,$nome,$cnpj,$email,$senha,$telefone,$celular,$endereco,$bairro,$numero_casa,$complemento,$path_imagem){
			$this->id=$id;
			$this->nome=$nome;
			$this->cnpj=$cnpj;
			$this->email=$email;
			$this->senha=$senha;
			$this->telefone=$telefone;
			$this->celular=$celular;
			$this->endereco=$endereco;
			$this->bairro=$bairro;
			$this->numero_casa=$numero_casa;
			$this->complemento=$complemento;
			$this->$pathImagem=$path_imagem;			
		}
		function getId(){
			return $this->id;			
		}
		function getNome(){
			return $this->nome;			
		}
		function getCnpj(){
			return $this->cnpj;			
		}
		function getEmail(){
			return $this->email;			
		}
		function getSenha(){
			return $this->senha;			
		}
		function getTelefone(){
			return $this->telefone;			
		}
		function getCelular(){
			return $this->celular;			
		}
		function getEndereco(){
			return $this->endereco;			
		}
		function getBairro(){
			return $this->bairro;			
		}
		function getNumeroCasa(){
			return $this->numero_casa;			
		}
		function getComplemento(){
			return $this->complemento;			
		}
		function getPathImagem(){
			return $this->pathImagem;			
		}
	}
?>