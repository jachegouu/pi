<?php
	class CategoriaBean{
		private $id;
		private $descricao;
		private $situacao;
		
		function setCategoria($id,$descricao,$situacao){
			$this->id=$id;
			$this->descricao=$descricao;	
			$this->situacao=$situacao;			
		}
		
		function setId($id){
			$this->id=$id;			
		}
		function setId($descricao){
			$this->descricao=$descricao;			
		}
		function setId($situacao){
			$this->situacao=$situacao;			
		}
		
		function getId(){
			return $this->id;			
		}
		function getDescricao(){
			return $this->descricao;			
		}
		function isSituacao(){
			return $this->situacao;			
		}		
	}
?>