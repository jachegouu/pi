<?php
	require_once '../class/EstabelecimentoBean.php';
	$estabelicimento = new EstabelecimentoBean();
	
	$path="";
	
	$estabelicimento->setEstabelicimento($_POST['id'], $_POST['nome'], 
	$_POST['cnpj'], $_POST['email'], $_POST['senha'], $_POST['telefone'], $_POST['celular'], 
	$_POST['endereco'], $_POST['bairro'],$_POST['numerocasa'], $_POST['complemento'],$path);
	
	
	
	
?>