<?php
	include '../banco/conexao.php';
	class ListaCategoria{
		function lista(){
			$lista=mysql_query("SELECT * FROM categoria_produto WHERE situacao=1");
			return $lista;
		}		
	}
?>