<?php header("Content-type: text/html; charset=iso8859-1"); 
	if ($_SERVER['REQUEST_METHOD'] == 'GET'){
		if(isset($_GET['erro'])){
			echo "<h1>Usu�rio e Senha invalidos!</h1>";
		}		
	}
?>
<html>
<head>
<title>Login - Ja Chegou</title>
<link href="./bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="./bootstrap/starter-template.css" rel="stylesheet">
<link href="./css/css_personalizado.css" rel="stylesheet">
<link rel="shortcut icon" href="../img/logo.png" type="../img/logo.png">
</head>
<body class="login-form">
	<div class="container-fluid" style="margin-top: 2%;">	
		<div class="col-md-4"></div>
		<div class="col-md-4" style="padding: 3%;">
			<!-- img alt="JaChegou" src="./img/login_imagem.png" width="100%" height="250px"> -->
			<img alt="JaChegou" src="./img/logo.png" width="100%" height="350px">
			<!--  <h1 style="color: white;">J� CHEGOU</h1>-->
			<fieldset>
				<br>				
				<form action="logarUsuario.php" method="post">
					<select class="form-control" id="tipoacesso" name="tipoacesso" >
							<option value="0">Administrador Portal</option>
							<option value="1">Estabelecimento</option>
					</select>
					<br><br>
					<input class="campo" type="text" name="login" id="login" placeholder="Login ..."><br><br>
					<input class="campo" type="password" name="senha" id="senha" placeholder="Senha ..."><br><br>
					<div align="right">
						<input class="botao-login" type="submit" value="Entrar">
					</div>
				</form>
			</fieldset>
		</div>
		<div class="col-md-4"></div>
	</div>
</body>
</html>
