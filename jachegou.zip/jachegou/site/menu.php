<nav class="header navbar navbar-inverse navbar-fixed-top menu">
	<div class="container" id="container">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle collapsed"
				data-toggle="collapse" data-target="#navbar" aria-expanded="false"
				aria-controls="navbar">
				<span class="sr-only">Toggle navigation</span> <span
					class="icon-bar"></span> <span class="icon-bar"></span> <span
					class="icon-bar"></span>
			</button>			
		</div>
		
		<div id="navbar" class="header collapse navbar-collapse">
			<ul class="nav navbar-nav">				
                                <li><a class="font2" style="color: white;" href="ListaProduto.php">Listar Produtos</a></li>
				<li><a class="font2" style="color: white;" href="CadastrarProduto.php">Cadastrar Produto</a></li>
				<li><a class="font2" style="color: white;" href="CadastrarCliente.php">Cadastro Estabelecimento</a></li>
				<li><a class="font2" style="color: white;" href="CadastrarUsuario.php">Cadastro Usu�rios</a></li>				
				<li><a class="font2" style="color: white;" href="#">Lista de Pedido</a></li>						
			</ul>
		</div>
	</div>
</nav>